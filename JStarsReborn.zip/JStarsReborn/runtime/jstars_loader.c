// JStarsReborn boot loader: maps the prepared J-Stars image (eboot + bundled libc/Fios2 modules),
// applies relocations, binds imports, runs module initializers and enters the original entry point.
//
// Imports the runtime does not implement are bound to traps that stop the process with the import's
// NID, library, symbol name and calling address. Nothing returns a fake success value.
//
// Structure follows the approach of HayatoG/iss_pc (probe.c) and Castlesea's inFAMOUS port; this file
// is written for J-Stars and carries none of their title-specific patches. GPL-2.0-or-later.
#define _GNU_SOURCE
#include "jstars_rt.h"
#include "jstars_os.h"
#include "jstars_isa.h"
#include <errno.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#endif

typedef struct { uint64_t base, size, init, tls_address, tls_memsz, tls_filesz, tls_module; } Module;
typedef struct { uint64_t address, size, flags; } Segment;
typedef struct { uint64_t target, kind, value; int64_t addend; } Reloc;
typedef struct { uint64_t index, address, kind; } Binding;

static uint8_t* image;
static size_t image_size, total_size;
static uint8_t *traps, *data_traps, *thunks;
static uint64_t import_count, module_count, seg_count, page;
static char (*import_names)[128];
static char** import_symbol; // from import-names.tsv
static Module modules[8];
static Segment* segs;
static int g_stage = 0; // 0 loading, 1 module init, 2 entry
static uint64_t g_entry, g_procparam;
void* rt_procparam(void) { return image + g_procparam; }
void* rt_image(void) { return image; }
// Per-module TLS template (PT_TLS image): module id -> {initial bytes, file size, memory size}.
int rt_tls_template(uint64_t module_id, const void** init, size_t* filesz, size_t* memsz) {
    for (uint64_t m = 0; m < module_count; ++m)
        if (modules[m].tls_module == module_id) {
            *init = image + modules[m].tls_address; *filesz = modules[m].tls_filesz; *memsz = modules[m].tls_memsz;
            return 1;
        }
    return 0;
}
void rt_set_stage(int s) { g_stage = s; }

// ---- logging ---------------------------------------------------------------------------------
static FILE* g_log;
static struct timespec g_t0;
void rt_log_open(const char* path) {
    g_log = os_fopen(path, "w");
    if (g_log) setvbuf(g_log, NULL, _IOLBF, 0);
    clock_gettime(CLOCK_MONOTONIC, &g_t0);
}
void rt_logf(const char* fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    double ms = (double)(t.tv_sec - g_t0.tv_sec) * 1e3 + (double)(t.tv_nsec - g_t0.tv_nsec) / 1e6;
    fprintf(stderr, "[%9.3f] %s\n", ms, buf);
    if (g_log) { fprintf(g_log, "[%9.3f] %s\n", ms, buf); fflush(g_log); }   // Windows C runtime ignores _IOLBF: flush so a crash keeps the log
}
const char* rt_import_name(uint32_t i) {
    return i < import_count && import_symbol[i] && *import_symbol[i] ? import_symbol[i] : "(unnamed NID)";
}

[[noreturn]] static void fail(const char* msg) {
    rt_logf("FATAL: %s", msg);
    rt_audio_flush_dump();
    fflush(NULL);
    _exit(2);
}

const char* rt_locate(uintptr_t a, char* out, size_t n);
static const char* locate(uintptr_t a, char* out, size_t n) { return rt_locate(a, out, n); }
const char* rt_locate(uintptr_t a, char* out, size_t n) {
    if (a >= (uintptr_t)image && a < (uintptr_t)image + image_size) {
        uint64_t off = a - (uintptr_t)image;
        const char* mod = "eboot.bin";
        uint64_t base = 0;
        static const char* names[] = {"libc.prx", "libSceFios2.prx"};
        for (uint64_t m = 0; m < module_count; ++m)
            if (off >= modules[m].base && off < modules[m].base + modules[m].size) {
                mod = names[m < 2 ? m : 1];
                base = modules[m].base;
            }
        snprintf(out, n, "%s+0x%" PRIx64, mod, off - base);
    } else {
        char w[200];
        snprintf(out, n, "host/other %s", os_where(a, w, sizeof w)); // names the host DLL (or the plain pointer)
    }
    return out;
}

// ---- unresolved import traps -----------------------------------------------------------------
// The trap is reached by a tail jump, so returning from here returns to the game's caller with this value in rax.
// By default nothing returns: an unimplemented import stops the run (exit 3) at its exact call site. The
// `online-probe` experiment is the one exception, for mapping the online path in a single run (docs/EXPERIMENTS.md).
static const char* import_library(uint32_t index) {
    const char* p = strchr(import_names[index], '#');
    return p ? p + 1 : import_names[index];
}
static int is_online_library(const char* lib) {
    return !strncmp(lib, "libSceNp", 8) || !strncmp(lib, "libSceNet", 9) || !strcmp(lib, "libSceSsl") ||
           !strcmp(lib, "libSceHttp") || !strcmp(lib, "libSceRudp");
}
static uint8_t* g_probe_seen;   // one byte per import: how many times this import was already reported
static int64_t GUEST_ABI unresolved(uint32_t index, uintptr_t arg0) {
    char where[96];
    uintptr_t ret = (uintptr_t)__builtin_return_address(0);
    const char* lib = import_library(index);
    if (g_probe_seen && is_online_library(lib)) {
        // Diagnosis only: report the console's "signed out" error instead of stopping, so one run records the whole
        // sequence the game tries. The answer is NOT a claim that this import behaves correctly.
        if (g_probe_seen[index] < 3) {
            g_probe_seen[index]++;
            rt_logf("ONLINE PROBE (experiment, not an implementation) %s [%s] called from %s (first arg 0x%" PRIxPTR ") -> 0x80550006%s",
                    import_names[index], rt_import_name(index), locate(ret, where, sizeof where), arg0,
                    g_probe_seen[index] == 3 ? " (further calls are not logged)" : "");
        }
        return (int64_t)(int32_t)0x80550006; // SCE_NP_ERROR_SIGNED_OUT
    }
    rt_logf("UNIMPLEMENTED IMPORT #%u %s [%s] called from %s (first arg 0x%" PRIxPTR ") stage=%s", index,
            import_names[index], rt_import_name(index), locate(ret, where, sizeof where), arg0,
            g_stage == 1 ? "module-init" : g_stage == 2 ? "entry" : "load");
    rt_audio_flush_dump();
    fflush(NULL);
    _exit(3);
}

#ifdef JSTARS_HEAPGUARD
void rt_heapguard_describe(uintptr_t addr, char* out, size_t cap);
#endif
static void fault(const OsFault* f) {
    char where[96];
    rt_logf("FAULT %s %#x (access %d) address %p at %s stage=%d",
#ifdef _WIN32
            "exception", (unsigned)f->signal,
#else
            "signal", (unsigned)f->signal,
#endif
            f->code, (void*)f->address, locate(f->rip, where, sizeof where), g_stage);
    uintptr_t fa = f->address;
#ifdef JSTARS_HEAPGUARD
    { char hg[400]; rt_heapguard_describe(fa, hg, sizeof hg); if (hg[0]) rt_logf("  HEAPGUARD: %s", hg); }
#endif
    if (data_traps && fa >= (uintptr_t)data_traps && fa < (uintptr_t)data_traps + (import_count + 1) * page) {
        uint32_t i = (uint32_t)((fa - (uintptr_t)data_traps) / page);
        rt_logf("  access to unimplemented DATA import #%u %s [%s]", i, import_names[i], rt_import_name(i));
    }
    static const char* rn[] = {"rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi", "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15"};
    for (int i = 0; i < 16; ++i) rt_logf("  %-3s = 0x%016llx", rn[i], (unsigned long long)f->gpr[i]);
    rt_logf("  rip = 0x%016llx", (unsigned long long)f->rip);
    rt_logf("  rflags = 0x%016llx", (unsigned long long)f->rflags);
    { // Faulting bytes: identifies MOVBE/BMI1 vs something else without needing the game file.
        uint8_t code[16];
        size_t got = os_safe_read(code, (const void*)f->rip, sizeof code);
        if (got) {
            char hex[64] = {0};
            size_t at = 0;
            for (size_t i = 0; i < got && at + 3 < sizeof hex; ++i) at += (size_t)snprintf(hex + at, sizeof hex - at, "%02x%s", code[i], i + 1 < got ? " " : "");
            rt_logf("  bytes at rip (%u): %s", (unsigned)got, hex);
            // Best-effort decode so a Haswell instruction names itself in the log (no side effects).
            {
                size_t dl = 0; char mn[16] = {0};
                if (jsi_decode(code, got, mn, sizeof mn, &dl))
                    rt_logf("  isa: %s (+%u)", mn[0] ? mn : "?", (unsigned)dl);
            }
        } else {
            rt_logf("  bytes at rip: unreadable");
        }
    }
    rt_logf("  faulting thread: %s", rt_current_thread_name());
    for (int i = 0; i < 24; ++i) {
        uintptr_t v = 0;
        if (os_safe_read(&v, (const uintptr_t*)f->rsp + i, sizeof v) != sizeof v) break;
        if (v >= (uintptr_t)image && v < (uintptr_t)image + image_size)
            rt_logf("  stack[%2d] -> %s", i, locate(v, where, sizeof where));
    }
    // host return addresses deeper on the stack (names the DLL and offset when the fault is inside a system or driver library)
    for (int i = 0, shown = 0; i < 128 && shown < 12; ++i) {
        uintptr_t v = 0;
        if (os_safe_read(&v, (const uintptr_t*)f->rsp + i, sizeof v) != sizeof v) break;
        if (v < 0x10000 || (v >= (uintptr_t)image && v < (uintptr_t)image + image_size)) continue;
        char w2[200]; const char* l = os_where(v, w2, sizeof w2);
        if (strchr(l, '+')) { rt_logf("  host stack[%3d] -> %s", i, l); ++shown; }
    }
    rt_audio_flush_dump();
    fflush(NULL);
    _exit(4);
}

// ---- boot file ---------------------------------------------------------------------------------
static uint64_t rd64(FILE* f) {
    uint64_t v;
    if (fread(&v, 8, 1, f) != 1) fail("truncated boot file");
    return v;
}
static int mapped(uint64_t a, uint64_t n) {
    for (uint64_t i = 0; i < seg_count; ++i)
        if (a >= segs[i].address && n <= segs[i].size && a - segs[i].address <= segs[i].size - n) return 1;
    return 0;
}
static int prot_of(uint64_t f) { return (f & 4 ? OS_PROT_R : 0) | (f & 2 ? OS_PROT_W : 0) | (f & 1 ? OS_PROT_X : 0); }

static void GUEST_ABI guest_exit(void) {
    rt_logf("guest called its exit function");
    rt_audio_flush_dump();
    fflush(NULL);
    _exit(0);
}

typedef struct { uint64_t argc; const char* argv[2]; } EntryParams;
static EntryParams g_params = {1, {"/app0/eboot.bin", NULL}};

static int g_sample_interval;
static int g_max_seconds, g_capture_flips, g_capture_interval = 60, g_capture_max = 3;
static void* monitor_main(void* arg);
// Periodic GPU statistics, optional frame capture and a wall-clock limit for evidence runs.
static void* monitor_main(void* arg) {
    (void)arg;
    uint64_t last[5] = {0}, captured = 0;
    for (int sec = 1;; ++sec) {
#ifdef _WIN32
        Sleep(1000);
#else
        sleep(1);
#endif
        uint64_t st[5];
        rt_gpu_stats(st);
        if (memcmp(st, last, sizeof st)) {
            rt_logf("GPU stats t=%ds: draws=%" PRIu64 " dispatches=%" PRIu64 " flips=%" PRIu64 " gnm_frames=%" PRIu64 " gpu_maps=%" PRIu64, sec, st[0], st[1], st[2], st[3], st[4]);
            memcpy(last, st, sizeof st);
        }
        if (g_capture_flips > 0 && st[2] >= (uint64_t)g_capture_flips && captured < g_capture_max && st[2] >= (uint64_t)captured * (uint64_t)g_capture_interval + (uint64_t)g_capture_flips) {
            rt_gpu_capture(1);
            ++captured;
            rt_logf("capture requested at flip %" PRIu64, st[2]);
        }
        rt_gpu_timing_tick(sec);
        if (g_sample_interval && sec % g_sample_interval == 0) { rt_sample_threads(); rt_thunk_report(); rt_fs_report(); }
        if (g_max_seconds && sec >= g_max_seconds) {
            rt_logf("--max-seconds %d reached; stopping (exit 7)", g_max_seconds);
            rt_audio_flush_dump();
    fflush(NULL);
            _exit(7);
        }
    }
    return NULL;
}


// ---- Native frame rate (--frame-rate 60; experimental) -----------------------------------------------------------------
// The same changes as tools/re/prepare_timing_experiment.py --engine-rate 60 --after-ticks 0 (Codex; measured: battle clock
// 0.99593x at 59.756 fps) plus tools/re/rate_constants.py (the literal 30 Hz constants). Applied in memory to CUSA01593 v01.02
// only: every original byte is checked first, and nothing is changed unless all of them match. docs/reverse-engineering/
// NATIVE_60_EXPERIMENT.md. Default 30: nothing is touched.
static int native_rate_patch(int rate, const Segment* segs, uint64_t ns, const Reloc* relocs, uint64_t nr) {
    if (rate == 30) return 0;
    if (rate != 60) { rt_logf("--frame-rate %d: only 30 and 60 are supported", rate); return -1; }
    enum { SITE = 0x433e6a, RESUME = 0x433e73, CAVE = 0x730100, COUNTER = 0x81f374, RATE_SITE = 0x1e01b1 };
    static const uint8_t site_orig[9] = {0x44, 0x89, 0xfe, 0xff, 0x90, 0xf0, 0x00, 0x00, 0x00};
    static const uint8_t rate_orig[10] = {0xbf, 0x1e, 0x00, 0x00, 0x00, 0xe8, 0x75, 0x41, 0x22, 0x00};
    static const struct { uint32_t addr; float v30; int step; } k[] = {
        {0x585c08, 1.0f / 30.0f, 1}, {0x5791ec, 30.0f, 0}, {0x5791f0, 30.0f, 0}, {0x575868, 30.0f, 0}, {0x57586c, 30.0f, 0}, {0x579200, 30.0f, 0}};
    // Trampoline (prepare_timing_experiment.trampoline(0)): mov esi,r15d; cmp dword [COUNTER],0; jb +5; mov esi,1;
    // call [rax+0xf0]; jmp RESUME. With threshold 0 the guest requests presentation mode 1 from the start.
    uint8_t cave[32];
    size_t n = 0;
    const uint8_t a1[] = {0x44, 0x89, 0xfe, 0x81, 0x3d};
    memcpy(cave + n, a1, sizeof a1); n += sizeof a1;
    int32_t disp = (int32_t)(COUNTER - (CAVE + 13)); memcpy(cave + n, &disp, 4); n += 4;
    uint32_t thr = 0; memcpy(cave + n, &thr, 4); n += 4;
    const uint8_t a2[] = {0x72, 0x05, 0xbe, 0x01, 0x00, 0x00, 0x00, 0xff, 0x90, 0xf0, 0x00, 0x00, 0x00, 0xe9};
    memcpy(cave + n, a2, sizeof a2); n += sizeof a2;
    int32_t back = (int32_t)(RESUME - (CAVE + (int64_t)n + 4)); memcpy(cave + n, &back, 4); n += 4;
    // checks
    if (ns < 1 || segs[0].address != 0 || segs[0].size != 7536868 || !(segs[0].flags & 1)) { rt_logf("--frame-rate 60: not the supported game build (segment layout)"); return -1; }
    if (CAVE + n > ((segs[0].size + 16383) & ~(uint64_t)16383)) { rt_logf("--frame-rate 60: no room for the trampoline"); return -1; }
    if (memcmp(image + SITE, site_orig, sizeof site_orig) || memcmp(image + RATE_SITE, rate_orig, sizeof rate_orig)) { rt_logf("--frame-rate 60: original code does not match (other game build?); not applied"); return -1; }
    for (size_t i = 0; i < n; ++i) if (image[CAVE + i]) { rt_logf("--frame-rate 60: trampoline area is not empty; not applied"); return -1; }
    for (size_t i = 0; i < sizeof k / sizeof *k; ++i) { float v; memcpy(&v, image + k[i].addr, 4); if (v != k[i].v30) { rt_logf("--frame-rate 60: constant %#x does not match; not applied", k[i].addr); return -1; } }
    for (uint64_t i = 0; i < nr; ++i) {
        const uint64_t t = relocs[i].target;
        const uint64_t ranges[][2] = {{SITE, RESUME}, {CAVE, CAVE + n}, {RATE_SITE, RATE_SITE + 10}};
        for (size_t r = 0; r < 3; ++r) if (t < ranges[r][1] && t + 8 > ranges[r][0]) { rt_logf("--frame-rate 60: a relocation overlaps the change; not applied"); return -1; }
        for (size_t c = 0; c < sizeof k / sizeof *k; ++c) if (t < k[c].addr + 4 && t + 8 > k[c].addr) { rt_logf("--frame-rate 60: a relocation overlaps a constant; not applied"); return -1; }
    }
    // apply
    memcpy(image + CAVE, cave, n);
    image[SITE] = 0xe9; int32_t jmp = (int32_t)(CAVE - SITE - 5); memcpy(image + SITE + 1, &jmp, 4); memset(image + SITE + 5, 0x90, 4);
    uint32_t r60 = 60; memcpy(image + RATE_SITE + 1, &r60, 4);
    for (size_t i = 0; i < sizeof k / sizeof *k; ++i) { float v = k[i].step ? 1.0f / 60.0f : 60.0f; memcpy(image + k[i].addr, &v, 4); }
    rt_logf("--frame-rate 60 (EXPERIMENTAL): engine rate 60, presentation mode 1, %u literal 30 Hz constants set for 60 Hz. "
            "Battle clock validated; movement/animation parity is not yet fully validated (docs/reverse-engineering/NATIVE_60_EXPERIMENT.md)",
            (unsigned)(sizeof k / sizeof *k));
    return 0;
}

// ---- Widescreen / ultrawide (--widescreen; experimental) ------------------------------------------------------------------
// The game builds every perspective projection in one routine (0x3ec310: fov in degrees, horizontal scale, h/w aspect, near,
// far). Its 60-degree field of view is horizontal: m00 = cot(fov/2) / scale, m11 = cot(fov/2) / (h/w). For the 16:9 views
// (h/w = 0.5625; shadow maps use 1.0 and are left alone) a cave multiplies the horizontal scale by the factor the presenter
// publishes (window aspect / frame aspect, at least 1), so a wider window shows more to the sides (Hor+) while the vertical view
// is unchanged, and the presenter stretches the 16:9 frame to fill the window. The 2D HUD is drawn into the same frame, so it
// is stretched with it. CUSA01593 v01.02 only; every original byte is checked first. docs/WIDESCREEN.md.
static int widescreen_patch(float* scale_cell, const Segment* segs, uint64_t ns, const Reloc* relocs, uint64_t nr) {
    enum { SITE = 0x3ec310, RESUME = 0x3ec319, CAVE = 0x730140 };
    static const uint8_t prologue[9] = {0x55, 0x48, 0x89, 0xe5, 0x53, 0x48, 0x83, 0xec, 0x18}; // push rbp; mov rbp,rsp; push rbx; sub rsp,0x18
    // movabs rax, scale_cell; vsubss xmm5,xmm2,[c916]; vandps xmm5,xmm5,[absmask]; vcomiss xmm5,[eps]; jae +4;
    // vmulss xmm1,xmm1,[rax]; (original prologue); jmp RESUME; data: absmask x4, 0.5625, 0.002 (assembled with GNU as)
    static const uint8_t code[0x58] = {
        0x48, 0xb8, 0, 0, 0, 0, 0, 0, 0, 0,             0xc5, 0xea, 0x5c, 0x2d, 0x3e, 0x00, 0x00, 0x00,
        0xc5, 0xd0, 0x54, 0x2d, 0x26, 0x00, 0x00, 0x00, 0xc5, 0xf8, 0x2f, 0x2d, 0x32, 0x00, 0x00, 0x00,
        0x73, 0x04, 0xc5, 0xf2, 0x59, 0x08,             0x55, 0x48, 0x89, 0xe5, 0x53, 0x48, 0x83, 0xec, 0x18,
        0xe9, 0, 0, 0, 0,                               0x90, 0x66, 0x0f, 0x1f, 0x84, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xff, 0xff, 0xff, 0x7f, 0xff, 0xff, 0xff, 0x7f, 0xff, 0xff, 0xff, 0x7f, 0xff, 0xff, 0xff, 0x7f,
        0x00, 0x00, 0x10, 0x3f, 0x6f, 0x12, 0x03, 0x3b};
    if (!scale_cell) { rt_logf("--widescreen: needs the GPU library; not applied"); return -1; }
    if (ns < 1 || segs[0].address != 0 || segs[0].size != 7536868 || !(segs[0].flags & 1)) { rt_logf("--widescreen: not the supported game build (segment layout); not applied"); return -1; }
    if (CAVE + sizeof code > ((segs[0].size + 4095) & ~(uint64_t)4095)) { rt_logf("--widescreen: no room for the cave; not applied"); return -1; }
    if (memcmp(image + SITE, prologue, sizeof prologue)) { rt_logf("--widescreen: original code does not match (other game build?); not applied"); return -1; }
    for (size_t i = 0; i < sizeof code; ++i) if (image[CAVE + i]) { rt_logf("--widescreen: cave area is not empty; not applied"); return -1; }
    for (uint64_t i = 0; i < nr; ++i) {
        const uint64_t t = relocs[i].target;
        if ((t < RESUME && t + 8 > SITE) || (t < CAVE + sizeof code && t + 8 > CAVE)) { rt_logf("--widescreen: a relocation overlaps the change; not applied"); return -1; }
    }
    uint8_t c[sizeof code];
    memcpy(c, code, sizeof c);
    const uint64_t cell = (uint64_t)(uintptr_t)scale_cell; memcpy(c + 2, &cell, 8);
    const int32_t back = (int32_t)(RESUME - (CAVE + 0x36)); memcpy(c + 0x32, &back, 4);
    memcpy(image + CAVE, c, sizeof c);
    image[SITE] = 0xe9; const int32_t jmp = (int32_t)(CAVE - (SITE + 5)); memcpy(image + SITE + 1, &jmp, 4); memset(image + SITE + 5, 0x90, 4);
    rt_logf("--widescreen (EXPERIMENTAL): 16:9 projections widened to the window (Hor+); the frame fills windows wider than 16:9");
    return 0;
}

// ---- Projection trace (--trace-projection; diagnostics for FSR / frame generation) -----------------------------------------
// Logs the parameters of every distinct perspective projection the game builds (routine 0x3ec310: fov in degrees, horizontal
// scale, h/w aspect, near, far) with the calling site, and how often each was built, so the main camera (near/far/field of view
// needed by FSR) can be told apart from shadow, UI and other cameras. A cave saves the arguments, calls proj_trace and continues
// into the widescreen cave or the original code. Reads only; the game's computation is unchanged.
static struct { uint64_t site; float fov, scale, aspect, znear, zfar; uint64_t count; } g_proj[64];
static unsigned g_proj_n; static uint64_t g_proj_calls; static volatile int g_proj_lock;
// args: the five float arguments as the cave saved them (xmm0..xmm4, 16 bytes apart); ret: the caller's return address.
// (Floats through memory, and the work in a host-ABI function: mingw-w64 GCC 13 hits an internal error otherwise.)
static __attribute__((noinline)) void proj_record(const float* args, uint64_t ret);
static void GUEST_ABI proj_trace(const float* args, uint64_t ret) { proj_record(args, ret); } // host ABI from here on
static __attribute__((noinline)) void proj_record(const float* args, uint64_t ret) {
    const float fov = args[0], scale = args[4], aspect = args[8], znear = args[12], zfar = args[16];
    const uint64_t site = ret - (uint64_t)(uintptr_t)image;
    while (__atomic_exchange_n(&g_proj_lock, 1, __ATOMIC_ACQUIRE)) {}
    unsigned i = 0;
    for (; i < g_proj_n; ++i)
        if (g_proj[i].site == site && g_proj[i].fov == fov && g_proj[i].scale == scale && g_proj[i].aspect == aspect &&
            g_proj[i].znear == znear && g_proj[i].zfar == zfar) break;
    int fresh = 0;
    if (i == g_proj_n && g_proj_n < 64) { g_proj[i].site = site; g_proj[i].fov = fov; g_proj[i].scale = scale; g_proj[i].aspect = aspect;
                                           g_proj[i].znear = znear; g_proj[i].zfar = zfar; g_proj[i].count = 0; ++g_proj_n; fresh = 1; }
    if (i < 64) ++g_proj[i].count;
    const uint64_t calls = ++g_proj_calls;
    __atomic_store_n(&g_proj_lock, 0, __ATOMIC_RELEASE);
    if (fresh) rt_logf("projection #%u: called from eboot+%#" PRIx64 ": fov %.3f deg, scale %.4f, h/w %.4f, near %.4f, far %.1f",
                       i, site, fov, scale, aspect, znear, zfar);
    if (calls % 6000 == 0) {
        char line[1024]; size_t n = 0;
        while (__atomic_exchange_n(&g_proj_lock, 1, __ATOMIC_ACQUIRE)) {}
        for (unsigned k = 0; k < g_proj_n && n < sizeof line - 32; ++k)
            n += (size_t)snprintf(line + n, sizeof line - n, " #%u=%" PRIu64, k, g_proj[k].count);
        __atomic_store_n(&g_proj_lock, 0, __ATOMIC_RELEASE);
        rt_logf("projection counts after %" PRIu64 " builds:%s", calls, line);
    }
}
static int projection_trace_patch(int widescreen_on, const Segment* segs, uint64_t ns, const Reloc* relocs, uint64_t nr) {
    enum { SITE = 0x3ec310, RESUME = 0x3ec319, CAVE = 0x730200, WS_CAVE = 0x730140 };
    static const uint8_t prologue[9] = {0x55, 0x48, 0x89, 0xe5, 0x53, 0x48, 0x83, 0xec, 0x18};
    // push rdi; sub rsp,0x60; save xmm0-4 at [rsp+16*i]; mov rdi,rsp; mov rsi,[rsp+0x68] (return address); movabs rax,proj_trace;
    // call rax; restore xmm0-4; add rsp,0x60; pop rdi (assembled with GNU as)
    static const uint8_t head[88] = {
        0x57, 0x48, 0x83, 0xec, 0x60, 0xc5, 0xf8, 0x11, 0x04, 0x24, 0xc5, 0xf8, 0x11, 0x4c, 0x24, 0x10, 0xc5, 0xf8, 0x11, 0x54, 0x24,
        0x20, 0xc5, 0xf8, 0x11, 0x5c, 0x24, 0x30, 0xc5, 0xf8, 0x11, 0x64, 0x24, 0x40, 0x48, 0x89, 0xe7, 0x48, 0x8b, 0x74, 0x24, 0x68,
        0x48, 0xb8, 0, 0, 0, 0, 0, 0, 0, 0, 0xff, 0xd0, 0xc5, 0xf8, 0x10, 0x04, 0x24, 0xc5, 0xf8, 0x10, 0x4c, 0x24, 0x10, 0xc5, 0xf8,
        0x10, 0x54, 0x24, 0x20, 0xc5, 0xf8, 0x10, 0x5c, 0x24, 0x30, 0xc5, 0xf8, 0x10, 0x64, 0x24, 0x40, 0x48, 0x83, 0xc4, 0x60, 0x5f};
    uint8_t c[128]; size_t n = sizeof head;
    memcpy(c, head, sizeof head);
    const uint64_t fn = (uint64_t)(uintptr_t)proj_trace; memcpy(c + 44, &fn, 8);
    if (widescreen_on) { c[n] = 0xe9; const int32_t d = (int32_t)(WS_CAVE - (CAVE + n + 5)); memcpy(c + n + 1, &d, 4); n += 5; }
    else { memcpy(c + n, prologue, 9); n += 9; c[n] = 0xe9; const int32_t d = (int32_t)(RESUME - (CAVE + n + 5)); memcpy(c + n + 1, &d, 4); n += 5; }
    if (ns < 1 || segs[0].address != 0 || segs[0].size != 7536868) { rt_logf("--trace-projection: not the supported game build; not applied"); return -1; }
    if (CAVE + n > ((segs[0].size + 4095) & ~(uint64_t)4095)) { rt_logf("--trace-projection: no room; not applied"); return -1; }
    static const uint8_t ws_site[1] = {0xe9};
    if (widescreen_on ? memcmp(image + SITE, ws_site, 1) : memcmp(image + SITE, prologue, 9)) { rt_logf("--trace-projection: unexpected code at the site; not applied"); return -1; }
    for (size_t i = 0; i < n; ++i) if (image[CAVE + i]) { rt_logf("--trace-projection: cave area is not empty; not applied"); return -1; }
    for (uint64_t i = 0; i < nr; ++i) if (relocs[i].target < CAVE + n && relocs[i].target + 8 > CAVE) { rt_logf("--trace-projection: relocation overlap; not applied"); return -1; }
    memcpy(image + CAVE, c, n);
    image[SITE] = 0xe9; const int32_t j = (int32_t)(CAVE - (SITE + 5)); memcpy(image + SITE + 1, &j, 4); memset(image + SITE + 5, 0x90, 4);
    rt_logf("--trace-projection: logging the game's perspective projections (diagnostics; the picture is unchanged)");
    return 0;
}

static void* guest_main(void* arg) {
    (void)arg;
    rt_thread_attach_main();
    const uint16_t cw = 0x037F; // the console's x87 control word (64-bit precision)
    __asm__ volatile("fldcw %0" : : "m"(cw));
    typedef int(GUEST_ABI * ModInit)(uint64_t, void*, void*);
    g_stage = 1;
    for (uint64_t m = 0; m < module_count; ++m) {
        rt_logf("module %" PRIu64 " initializer at image+0x%" PRIx64, m, modules[m].init);
        int r = ((ModInit)(image + modules[m].init))(0, NULL, NULL);
        rt_logf("module %" PRIu64 " initializer returned %d", m, r);
        if (r) fail("module initializer failed");
    }
    rt_jsnet_start(); // the online session starts with the game (as in bbport)
    g_stage = 2;
    rt_logf("entering original x86-64 code at image+0x%" PRIx64, g_entry);
    typedef void(GUEST_ABI * Entry)(void*, void (*)(void));
    ((Entry)(image + g_entry))(&g_params, (void (*)(void))guest_exit);
    fail("entry returned");
}

int main(int argc, char** argv) {
#ifdef _WIN32
    // Paths from the launcher may contain any character: take the arguments from the wide command line as UTF-8
    // (every file the runtime opens goes through the UTF-8 helpers in jstars_os.c).
    {
        int wc = 0;
        LPWSTR* wv = CommandLineToArgvW(GetCommandLineW(), &wc);
        if (wv && wc > 0) {
            char** u = calloc((size_t)wc + 1, sizeof *u);
            for (int i = 0; u && i < wc; ++i) {
                int n = WideCharToMultiByte(CP_UTF8, 0, wv[i], -1, NULL, 0, NULL, NULL);
                u[i] = malloc(n > 0 ? (size_t)n : 1);
                if (u[i]) { u[i][0] = 0; if (n > 0) WideCharToMultiByte(CP_UTF8, 0, wv[i], -1, u[i], n, NULL, NULL); }
            }
            if (u) { argc = wc; argv = u; }
            LocalFree(wv);
        }
    }
#endif
    const char *boot = NULL, *logpath = "jstars-boot.log", *gpu_dir = NULL, *capture_dir = NULL, *game_root = NULL, *user_dir = NULL, *pad_script = NULL, *experiments = NULL;
    int online = 0, trace_net = 0, trace_np = 0, shadnet = 0, frame_rate = 30;
    uint16_t lobby_port = 0;
    int frame_stats = 0, flip_rate = -1, flip_rate_after = 0, ffx_probe = 0;
    const char *vblank_hz = NULL, *present_mode = NULL;
    const char* lobby_peers = NULL;
    int check_only = 0, selftest = 0, audit_dump = 0, stop_at_gnm = 0, win_w = 1280, win_h = 720, fullscreen = 0, widescreen = 0, match_refresh = 0, trace_projection = 0;
    for (int i = 1; i < argc; ++i) {
        if (!strcmp(argv[i], "--version")) { printf("JStarsReborn runtime %s\n", JSTARS_RUNTIME_VERSION); return 0; }
        else if (!strcmp(argv[i], "--boot") && i + 1 < argc) boot = argv[++i];
        else if (!strcmp(argv[i], "--volume") && i + 1 < argc) rt_audio_set_volume(atoi(argv[++i]));
        else if (!strcmp(argv[i], "--log") && i + 1 < argc) logpath = argv[++i];
        else if (!strcmp(argv[i], "--check-imports")) check_only = 1;
        else if (!strcmp(argv[i], "--selftest-host")) selftest = 1;
        else if (!strcmp(argv[i], "--selftest-jsnet")) selftest = 2;
        else if (!strcmp(argv[i], "--audit-dump")) audit_dump = 1;
        // Diagnostic mode of checkpoint 0.2.2: no GPU library; the process stops (exit 3) at the first Gnm call.
        else if (!strcmp(argv[i], "--stop-at-first-gnm")) stop_at_gnm = 1;
        else if (!strcmp(argv[i], "--gpu-dir") && i + 1 < argc) gpu_dir = argv[++i];
        else if (!strcmp(argv[i], "--game-root") && i + 1 < argc) game_root = argv[++i];
        else if (!strcmp(argv[i], "--user-dir") && i + 1 < argc) user_dir = argv[++i];
        else if (!strcmp(argv[i], "--title-id") && i + 1 < argc) rt_set_title_id(argv[++i]);
        else if (!strcmp(argv[i], "--capture-dir") && i + 1 < argc) capture_dir = argv[++i];
        else if (!strcmp(argv[i], "--window") && i + 1 < argc) sscanf(argv[++i], "%dx%d", &win_w, &win_h);
        else if (!strcmp(argv[i], "--max-seconds") && i + 1 < argc) g_max_seconds = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--pad-script") && i + 1 < argc) pad_script = argv[++i];
        else if (!strcmp(argv[i], "--sample-threads") && i + 1 < argc) g_sample_interval = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--no-keyboard")) rt_input_set_keyboard(0);
        else if (!strcmp(argv[i], "--no-audio")) rt_audio_set_device_enabled(0);
        else if (!strcmp(argv[i], "--dump-audio") && i + 1 < argc) rt_audio_set_dump(argv[++i]);
        else if (!strcmp(argv[i], "--pad-none")) rt_input_set_none(1);
        else if (!strcmp(argv[i], "--count-imports")) rt_thunk_set_counting(1);
        else if (!strcmp(argv[i], "--experiment") && i + 1 < argc) experiments = argv[++i];
        else if (!strcmp(argv[i], "--online")) online = 1;
        else if (!strcmp(argv[i], "--shadnet")) shadnet = online = 1;
        else if (!strcmp(argv[i], "--frame-rate") && i + 1 < argc) frame_rate = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--shadnet-server") && i + 1 < argc) { static char e[300]; snprintf(e, sizeof e, "JSTARS_SHADNET_SERVER=%s", argv[++i]); putenv(e); }
        else if (!strcmp(argv[i], "--frame-stats")) frame_stats = 1;
        else if (!strcmp(argv[i], "--ffx-probe")) ffx_probe = 1;
        else if (!strcmp(argv[i], "--fullscreen")) fullscreen = 1;
        else if (!strcmp(argv[i], "--match-refresh")) match_refresh = 1;
        else if (!strcmp(argv[i], "--trace-projection")) trace_projection = 1;
        else if (!strcmp(argv[i], "--shader-cache") && i + 1 < argc) os_setenv("JSTARS_SHADER_CACHE", argv[++i]); // persistent shader/pipeline cache
        else if (!strcmp(argv[i], "--fsr")) os_setenv("JSTARS_FSR", "1"); // AMD FSR 1 upscaling + RCAS sharpening in the presenter
        else if (!strcmp(argv[i], "--fsr-sharpness") && i + 1 < argc) { // RCAS attenuation in stops: 0 sharpest .. 2 softest
            char v[16]; double a = atof(argv[++i]); if (a < 0) a = 0; if (a > 2) a = 2;
            snprintf(v, sizeof v, "%d", (int)(a * 1000 + 0.5)); os_setenv("JSTARS_FSR_ATTENUATION_MILLI", v);
        }
        else if (!strcmp(argv[i], "--widescreen")) widescreen = 1;
        else if (!strcmp(argv[i], "--flip-rate") && i + 1 < argc) flip_rate = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--flip-rate-after") && i + 1 < argc) flip_rate_after = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--vblank-hz") && i + 1 < argc) vblank_hz = argv[++i];
        else if (!strcmp(argv[i], "--present-mode") && i + 1 < argc) present_mode = argv[++i];
        else if (!strcmp(argv[i], "--lobby-port") && i + 1 < argc) lobby_port = (uint16_t)atoi(argv[++i]);
        else if (!strcmp(argv[i], "--lobby-peer") && i + 1 < argc) lobby_peers = argv[++i];
        else if (!strcmp(argv[i], "--trace-net")) trace_net = 1;
        else if (!strcmp(argv[i], "--trace-np")) trace_np = 1;
        else if (!strcmp(argv[i], "--cpu-features")) {
            JsiCpuWords w = jsi_cpu_words();
            char fatal[128] = {0}, rw[128] = {0};
            int nf = jsi_missing_fatal(w, fatal, sizeof fatal);
            unsigned rwm = jsi_missing_rewritable(w, rw, sizeof rw);
            if (nf) printf("CPU: missing fatal %s\n", fatal);
            else if (rwm) printf("CPU: missing %s\n", rw);
            else printf("CPU: complete\n");
            return nf ? 20 : 0;
        }
        else if (!strcmp(argv[i], "--trace-draws") && i + 1 < argc) { ++i; os_setenv("JGPU_TRACE_DRAWS", argv[i]); }
        else if (!strcmp(argv[i], "--capture-flips") && i + 1 < argc) g_capture_flips = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--capture-interval") && i + 1 < argc) g_capture_interval = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--capture-max") && i + 1 < argc) g_capture_max = atoi(argv[++i]);
        else { fprintf(stderr, "usage: %s --boot boot-linked.bin [--log file] [--check-imports] [--stop-at-first-gnm] [--selftest-host] [--audit-dump]\n"
                               "       [--game-root dir] [--user-dir dir] [--gpu-dir dir] [--capture-dir dir] [--window WxH] [--fullscreen] [--match-refresh] [--widescreen] [--trace-projection] [--shader-cache dir] [--fsr] [--fsr-sharpness 0-2] [--max-seconds n] [--capture-flips n]\n"
                               "       [--capture-interval flips] [--capture-max n] [--pad-script file] [--no-keyboard] [--no-audio] [--volume 0-100] [--dump-audio prefix] [--pad-none] [--sample-threads seconds] [--count-imports] [--trace-draws first,count] [--experiment names] [--frame-rate 30|60] [--frame-stats] [--ffx-probe] [--flip-rate n] [--flip-rate-after s] [--vblank-hz n] [--present-mode Fifo|Mailbox|Immediate] [--online] [--shadnet] [--shadnet-server host[:port]] [--lobby-port n] [--lobby-peer ip[,ip]] [--trace-net] [--trace-np]\n", argv[0]); return 1; }
    }
    if (audit_dump) { extern void rt_audit_dump(void*); rt_audit_dump(stdout); return 0; }
    if (selftest) { rt_log_open(logpath); extern int rt_selftest_host(const char*); char sd[4096]; snprintf(sd, sizeof sd, "%s.selftest", logpath); if (selftest == 2) { extern int rt_selftest_jsnet(const char*); return rt_selftest_jsnet(sd); } return rt_selftest_host(sd); }
    if (!boot) { fprintf(stderr, "--boot is required\n"); return 1; }
    rt_log_open(logpath);
    rt_logf("JStarsReborn runtime %s", JSTARS_RUNTIME_VERSION);
    jsi_log_startup();
    os_set_isa_prehook(jsi_handle_fault);
#ifdef _WIN32
    // 1 ms timer resolution for this process (Windows' default tick is 15.6 ms): the game's own sleeps and waits, and the renderer's
    // vblank loop, otherwise wake only on that tick, which showed as frames alternating between 16 and 31 ms.
    {
        typedef unsigned(WINAPI * TimeBeginPeriod)(unsigned);
        HMODULE winmm = LoadLibraryW(L"winmm.dll");
        TimeBeginPeriod tbp = winmm ? (TimeBeginPeriod)(void*)GetProcAddress(winmm, "timeBeginPeriod") : NULL;
        rt_logf("timer resolution: %s", tbp && tbp(1) == 0 ? "1 ms (timeBeginPeriod)" : "Windows default (timeBeginPeriod unavailable)");
    }
#endif
    if (pad_script) rt_input_load_script(pad_script);
    if (experiments) rt_set_experiments(experiments);
    rt_net_configure(online, trace_net);
    rt_np_configure(trace_np);
    rt_rooms_configure(lobby_port, lobby_peers);
    rt_gpu_timing_configure(frame_stats, flip_rate, flip_rate_after);
    // The renderer reads these once at start (gpu/shim/core/emulator_settings.h). Experiments only; the defaults are unchanged.
    if (vblank_hz) { static char e1[64]; snprintf(e1, sizeof e1, "JSTARS_VBLANK_HZ=%s", vblank_hz); putenv(e1); rt_logf("experiment: vblank %s Hz", vblank_hz); }
    if (present_mode) { static char e2[64]; snprintf(e2, sizeof e2, "JSTARS_PRESENT_MODE=%s", present_mode); putenv(e2); rt_logf("experiment: present mode %s", present_mode); }
    if (flip_rate >= 0) rt_logf("experiment: --flip-rate %d replaces the flip rate the game asks for%s", flip_rate, flip_rate_after > 0 ? " (from --flip-rate-after seconds on)" : "");
    if (shadnet) rt_logf("--shadnet: online through a shadNet server (%s); matches are peer-to-peer. No PlayStation Network service is contacted.",
                         getenv("JSTARS_SHADNET_SERVER") && *getenv("JSTARS_SHADNET_SERVER") ? getenv("JSTARS_SHADNET_SERVER") : "no server set");
    else if (online) rt_logf("--online: the network layer is active. The game gets real UDP sockets on this host; "
                        "no PlayStation Network service is contacted and no account is used.");
    {
        char udir[4096];
        if (!user_dir) { snprintf(udir, sizeof udir, "%s.user", logpath); user_dir = udir; }
        rt_fs_configure(game_root, user_dir);
        if (shadnet) putenv("JSTARS_ONLINE=1");
    }
    // Guest-visible memory is placed inside the console's 40-bit user space (see jstars_os.c): GPU shader/descriptor
    // addresses are 40-bit and the SDK code requires the high half of a shader address to be zero. This must happen
    // before the first guest allocation; it applies to every mode.
    os_va_window(0x800000000ull, 0x10000000000ull);
    setvbuf(stdout, NULL, _IONBF, 0);
    page = 16384; // the console page size: segment alignment in the boot file
    if (os_page_size() > page) fail("host page size exceeds the guest page size");
    rt_logf("jstars-boot: boot file %s", boot);

    FILE* f = os_fopen(boot, "rb");
    if (!f) fail("cannot open boot file");
    char magic[8];
    if (fread(magic, 1, 8, f) != 8 || memcmp(magic, "JSTBOOT5", 8)) fail("bad boot file signature (run tools/prepare)");
    uint64_t size = rd64(f), entry = rd64(f), ns = rd64(f), nr = rd64(f);
    import_count = rd64(f);
    (void)rd64(f); // flags
    g_procparam = rd64(f);
    for (int i = 0; i < 4; ++i) (void)rd64(f); // eboot TLS (empty for this title)
    module_count = rd64(f);
    if (!size || size > (512u << 20) || entry >= size || !ns || ns > 64 || nr > 1000000 || import_count > 100000 ||
        !module_count || module_count > 8) fail("boot file limits exceeded");
    for (uint64_t m = 0; m < module_count; ++m) {
        Module* x = &modules[m];
        x->base = rd64(f); x->size = rd64(f); x->init = rd64(f); x->tls_address = rd64(f);
        x->tls_memsz = rd64(f); x->tls_filesz = rd64(f); x->tls_module = rd64(f);
    }
    uint64_t nb = rd64(f);
    if (nb > import_count) fail("bad binding count");
    Binding* bind = calloc(nb ? nb : 1, sizeof *bind);
    uint64_t* bound = calloc(import_count + 1, sizeof *bound);
    uint8_t* bound_kind = calloc(import_count + 1, 1);
    for (uint64_t i = 0; i < nb; ++i) {
        bind[i].index = rd64(f); bind[i].address = rd64(f); bind[i].kind = rd64(f);
        if (bind[i].index >= import_count) fail("bad binding index");
        bound[bind[i].index] = bind[i].address; bound_kind[bind[i].index] = (uint8_t)bind[i].kind;
    }
    segs = calloc(ns, sizeof *segs);
    seg_count = ns;
    for (uint64_t i = 0; i < ns; ++i) {
        segs[i].address = rd64(f); segs[i].size = rd64(f); segs[i].flags = rd64(f);
        if (segs[i].address > size || segs[i].size > size - segs[i].address || segs[i].address % page || segs[i].flags > 7)
            fail("bad segment");
    }
    import_names = calloc(import_count + 1, 128);
    if (fread(import_names, 128, import_count, f) != import_count) fail("truncated import names");
    Reloc* relocs = calloc(nr ? nr : 1, sizeof *relocs);
    for (uint64_t i = 0; i < nr; ++i) {
        relocs[i].target = rd64(f); relocs[i].kind = rd64(f); relocs[i].value = rd64(f); relocs[i].addend = (int64_t)rd64(f);
        if (!mapped(relocs[i].target, 8) || relocs[i].kind > 2 || (relocs[i].kind && relocs[i].value >= import_count))
            fail("bad relocation");
    }
    // Symbol names (diagnostics only) from import-names.tsv beside the boot file.
    import_symbol = calloc(import_count + 1, sizeof *import_symbol);
    {
        char p[4096];
        snprintf(p, sizeof p, "%s", boot);
        char* slash = strrchr(p, '/');
        char* bslash = strrchr(p, '\\');
        if (bslash && (!slash || bslash > slash)) slash = bslash;
        snprintf(slash ? slash + 1 : p, sizeof p - (size_t)(slash ? slash + 1 - p : 0), "import-names.tsv");
        FILE* t = os_fopen(p, "r");
        if (t) {
            char line[512];
            uint64_t i = 0;
            while (i < import_count && fgets(line, sizeof line, t)) {
                char* tab = strchr(line, '\t');
                if (!tab) { ++i; continue; }
                *tab = 0;
                char* nl = strchr(tab + 1, '\n');
                if (nl) *nl = 0;
                if (strcmp(line, import_names[i]) == 0) import_symbol[i] = strdup(tab + 1);
                ++i;
            }
            fclose(t);
        } else {
            rt_logf("note: %s not found; imports will be reported by NID only", p);
        }
    }

    // Reserve image + import trap pages in one low-address mapping.
    image_size = (size + page - 1) & ~(page - 1);
    size_t trap_bytes = (import_count * 32 + page) & ~(page - 1);
    size_t data_bytes = (import_count + 1) * page;
    size_t thunk_bytes = (rt_thunk_bytes(import_count) + page - 1) & ~(page - 1);
    size_t jit_bytes = 64 * 1024;   // inline replacements for hot BMI1 instructions (jsi_fast_patch_hot)
    total_size = image_size + trap_bytes + data_bytes + thunk_bytes + jit_bytes;
    void* want = (void*)0x200000000ull;
    void* mem = os_map_anon(want, total_size, OS_PROT_R | OS_PROT_W, OS_MAP_FIXED_NOREPLACE);
    if (!mem) mem = os_map_anon(NULL, total_size, OS_PROT_R | OS_PROT_W, OS_MAP_ANYWHERE);
    if (!mem) fail("cannot reserve guest image");
    image = mem;
    traps = image + image_size;
    data_traps = traps + trap_bytes;
    thunks = data_traps + data_bytes;
    uint8_t* jit = thunks + thunk_bytes;
    rt_thunks_init(thunks, import_count);
    if (fread(image, 1, size, f) != size) fail("truncated image");
    fclose(f);
    rt_logf("image mapped at %p (%" PRIu64 " bytes, %" PRIu64 " segments, %" PRIu64 " relocations, %" PRIu64 " imports)",
            (void*)image, size, ns, nr, import_count);

    if (rt_experiment("online-probe")) g_probe_seen = calloc(import_count ? import_count : 1, 1);
    for (uint64_t i = 0; i < import_count; ++i) {
        uint8_t* t = traps + i * 32;
        uintptr_t h = (uintptr_t)unresolved;
        uint32_t idx = (uint32_t)i;
        t[0] = 0x48; t[1] = 0x89; t[2] = 0xfe;       // mov rsi, rdi
        t[3] = 0xbf; memcpy(t + 4, &idx, 4);          // mov edi, index
        t[8] = 0x48; t[9] = 0xb8; memcpy(t + 10, &h, 8); // movabs rax, handler
        t[18] = 0xff; t[19] = 0xe0;                   // jmp rax
    }

    // The GPU library must be running before imports are bound: its exports are registered at start-up.
    if (!stop_at_gnm && !check_only) {
        char gdir[4096], cdir[4096];
        if (!gpu_dir) { snprintf(gdir, sizeof gdir, "%s.gpu", logpath); gpu_dir = gdir; }
        if (!capture_dir) { snprintf(cdir, sizeof cdir, "%s.captures", logpath); capture_dir = cdir; }
        if (rt_gpu_start("J-Stars Victory VS+", gpu_dir, capture_dir, win_w, win_h,
                         (fullscreen ? RT_DISPLAY_FULLSCREEN : 0) | (match_refresh ? RT_DISPLAY_MATCH_REFRESH : 0))) {
            rt_logf("GPU library did not start; run with --stop-at-first-gnm for the loader-only diagnostic");
            return 6;
        }
        if (ffx_probe) rt_gpu_fsr_probe();
    }
    // Online libraries (--shadnet): registered after the GPU library (their kernel calls go through its shim) and once the
    // image is loaded (they read the game's compiled SDK version), before imports are bound so they take precedence.
    if (shadnet && !check_only) rt_jsnet_setup(game_root);

    uint64_t n_host = 0, n_module = 0, n_trap = 0;
    uint8_t* seen = calloc(import_count + 1, 1);
    for (uint64_t i = 0; i < nr; ++i) {
        uintptr_t v;
        if (!relocs[i].kind) {
            v = (uintptr_t)image + relocs[i].value;
        } else {
            uint64_t k = relocs[i].value;
            int is_data = relocs[i].kind == 2;
            void* host = rt_resolve(import_names[k], import_symbol[k] ? import_symbol[k] : "", is_data);
            const char* how;
            if (host) {
                // Function imports go through a first-call tracing thunk (jstars_thunk.c); data stays direct.
                void* target = is_data ? host : rt_thunk_for((uint32_t)k, host, import_names[k], rt_resolve_name(), rt_resolve_origin());
                v = (uintptr_t)target + relocs[i].addend; how = "host";
            }
            else if (bound[k] && bound_kind[k] == relocs[i].kind) { v = (uintptr_t)image + bound[k] + relocs[i].addend; how = "module"; }
            else { v = is_data ? (uintptr_t)(data_traps + page * k + relocs[i].addend) : (uintptr_t)(traps + 32 * k); how = "trap"; }
            if (!seen[k]) {
                seen[k] = 1;
                if (how[0] == 'h') ++n_host; else if (how[0] == 'm') ++n_module; else ++n_trap;
                if (check_only && how[0] == 't') rt_logf("MISSING #%" PRIu64 " %s [%s]%s", k, import_names[k], rt_import_name((uint32_t)k), is_data ? " (data)" : "");
            }
        }
        memcpy(image + relocs[i].target, &v, 8);
    }
    rt_logf("imports bound: %" PRIu64 " host, %" PRIu64 " game modules, %" PRIu64 " unimplemented (trapped)", n_host, n_module, n_trap);
    if (check_only) return n_trap ? 1 : 0;
    if (native_rate_patch(frame_rate, segs, ns, relocs, nr) && frame_rate != 30)
        rt_logf("--frame-rate %d was not applied: the game runs at its own 30 fps", frame_rate);
    int widescreen_on = 0;
    if (widescreen) {
        if (widescreen_patch(rt_gpu_widescreen(0), segs, ns, relocs, nr)) rt_logf("--widescreen was not applied: 16:9 picture");
        else { rt_gpu_widescreen(1); widescreen_on = 1; }
    }
    if (trace_projection) projection_trace_patch(widescreen_on, segs, ns, relocs, nr);

    // CPUs without LZCNT/BMI1 run LZCNT/TZCNT as BSR/BSF without any fault (wrong results). Rewrite them to UD2 while the
    // image is still writable; the ISA fault handler (jstars_isa.c) emulates each one. No-op on CPUs that have the sets.
    for (uint64_t i = 0; i < ns; ++i)
        if (segs[i].flags & 1) jsi_patch_code(image + segs[i].address, (size_t)segs[i].size);
    // Hot BMI1 instructions (ANDN/BEXTR/BLSR...) would otherwise take a fault each time. Only for the build whose hot sites
    // were measured; every other build keeps using the fault handler.
    if (size == 11028540 && ns >= 1 && segs[0].size == 7536868 && (segs[0].flags & 1))
        jsi_fast_patch_hot(image, (size_t)size, jit, jit_bytes);

    if (os_protect(image, image_size, 0)) fail("protect image");
    for (uint64_t i = 0; i < ns; ++i)
        if (os_protect(image + segs[i].address, (segs[i].size + page - 1) & ~(page - 1), prot_of(segs[i].flags))) fail("protect segment");
    os_protect(traps, trap_bytes, OS_PROT_R | OS_PROT_X);
    os_protect(data_traps, data_bytes, 0);
    os_protect(thunks, thunk_bytes, OS_PROT_R | OS_PROT_W | OS_PROT_X);
    os_protect(jit, jit_bytes, OS_PROT_R | OS_PROT_X);
    os_install_fault_handler(fault);

    if (!stop_at_gnm) {
        pthread_t mon;
        pthread_create(&mon, NULL, monitor_main, NULL);
    } else {
        rt_logf("diagnostic mode: GPU library not started (stops at the first Gnm call)");
    }

    g_entry = entry;
    // The guest main thread gets a large stack, as on the console.
    pthread_attr_t at;
    pthread_attr_init(&at);
    pthread_attr_setstacksize(&at, 8u << 20);
    pthread_t th;
    if (pthread_create(&th, &at, guest_main, NULL)) fail("cannot start guest main thread");
    pthread_join(th, NULL);
    return 0;
}
